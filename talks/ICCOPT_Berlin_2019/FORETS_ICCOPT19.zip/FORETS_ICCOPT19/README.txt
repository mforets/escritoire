Open a terminal and do:

$ jupyter nbconvert Talk_ICCOPT2019.ipynb --to slides --post serve
